//
//  AdversityViewController.swift
//  OhMyBranding
//
//  Created by Beatriz Duque on 03/06/21.
//

import UIKit

class AdversityViewController: UIViewController {

    
    @IBOutlet weak var field: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //configurando o espaço de insercao de texto
        field.returnKeyType = .done
        field.autocapitalizationType = .words
        field.delegate = self
    }

}

extension AdversityViewController: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //essa funcao faz com que a tecla return do teclado faca o app aceitar a entrada e o teclado abaixe
        textField.resignFirstResponder()
        return true
    }
}
