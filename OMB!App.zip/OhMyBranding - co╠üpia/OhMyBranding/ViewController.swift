//
//  ViewController.swift
//  OhMyBranding
//
//  Created by Beatriz Duque on 01/06/21.
//

import UIKit
var indiceFontes = 0
var indicePaletas = 0
var indiceIcons = 0

class BrandViewController: UIViewController {
    
    //ImageView decorativa
    @IBOutlet weak var imgDecorativa: UIImageView!
    
    
    //variavel que guarda o tipo de texto
    let fonts = ["KohinoorBangla-Regular","SF-Compact","TimesNewRomanPSMT"]
    
    //variavel que guarda o tipo de paleta
    let paletas = ["final0","final1","final2","final3","final4","final5"]
    
    //variavel que guarda os icones
    let icons = ["logo1","logo2","logo3","logo4","logo5","logo6","logo7"]
    
    
    //vetores com o Hex
    let hexColors1 = ["#8D8989","#8B3030","#CCB4DD","#AAD8D3","#F6DCBF","#282746"]
    let hexColors2 = ["#0F3319","#D69393","#FFC4C4","#09ADB5","#F6A540","#047580"]
    let hexColors3 = ["#FFFFFF","#C4C4C4","#C4F4FF","#393E46","#E0711A","#FDD149"]
    
    //Botoes de tipografia
    
    @IBOutlet weak var tipo1: UIButton!
    @IBOutlet weak var tipo2: UIButton!
    @IBOutlet weak var tipo3: UIButton!
    
    
    //Botoes de paletas
    @IBOutlet weak var palet1: UIButton!
    @IBOutlet weak var palet2: UIButton!
    @IBOutlet weak var palet3: UIButton!
    @IBOutlet weak var palet4: UIButton!
    @IBOutlet weak var palet5: UIButton!
    @IBOutlet weak var palet6: UIButton!
    
    //botoes de logos
    @IBOutlet weak var logo1: UIButton!
    @IBOutlet weak var logo2: UIButton!
    @IBOutlet weak var logo3: UIButton!
    @IBOutlet weak var logo4: UIButton!
    @IBOutlet weak var logo5: UIButton!
    @IBOutlet weak var logo6: UIButton!
    @IBOutlet weak var logo7: UIButton!
    
    
    // Variaveis que armazenarao os resultados
    @IBOutlet weak var result1: UIImageView!
    @IBOutlet weak var resultText: UILabel!
    @IBOutlet weak var resultPalet: UIImageView!
    @IBOutlet weak var hexa1: UILabel!
    @IBOutlet weak var hexa2: UILabel!
    @IBOutlet weak var hexa3: UILabel!
    
    //variaveis de armazenamentolocal
    var myResult: UILabel = UILabel()
    
    //textField que guarda a variavel com o nome
    
    @IBOutlet weak var brandTitle: UITextField!
    
    //botao que gera resultado
    @IBOutlet weak var resultButton: UIButton!
    @IBOutlet weak var showResults: UIImageView!
    
    override func viewDidLoad() {
        view.backgroundColor = .white
        super.viewDidLoad()
    }
    
    
    //funcoes que setam as fontes selecionadas
    @IBAction func choose1(_ sender: Any) {
        if (tipo1.backgroundColor == .systemGray){
            tipo1.backgroundColor = nil
        }
        else{tipo1.backgroundColor = .systemGray}
        indiceFontes = 0
    }
    @IBAction func choose2(_ sender: Any) {
        if (tipo2.backgroundColor == .systemGray){
            tipo2.backgroundColor = nil
        }
        else{tipo2.backgroundColor = .systemGray}
        indiceFontes = 1
    }
    @IBAction func choose3(_ sender: Any) {
        if (tipo3.backgroundColor == .systemGray){
            tipo3.backgroundColor = nil
        }
        else{tipo3.backgroundColor = .systemGray}
        indiceFontes = 2
    }
    
    //funcoes que setam a paleta de cor selecionada
    
    @IBAction func choosePalet1(_ sender: Any) {
        indicePaletas = 0
    }
    @IBAction func choosePalet2(_ sender: Any) {
        indicePaletas = 1
    }
    @IBAction func choosePalet3(_ sender: Any) {
        indicePaletas = 2
    }
    @IBAction func choosePalet4(_ sender: Any) {
        indicePaletas = 3
    }
    @IBAction func choosePalet5(_ sender: Any) {
        indicePaletas = 4
    }
    @IBAction func choosePalet6(_ sender: Any) {
        indicePaletas = 5
    }

    //funcoes que setam o icone selecionado
    
    @IBAction func chooseIcon1(_ sender: Any) {
        indiceIcons = 0
    }
    @IBAction func chooseIcon2(_ sender: Any) {
        indiceIcons = 1
    }
    @IBAction func chooseIcon3(_ sender: Any) {
        indiceIcons = 2
    }
    @IBAction func chooseIcon4(_ sender: Any) {
        indiceIcons = 3
    }
    @IBAction func chooseIcon5(_ sender: Any) {
        indiceIcons = 4
    }
    @IBAction func chooseIcon6(_ sender: Any) {
        indiceIcons = 5
    }
    @IBAction func chooseIcon7(_ sender: Any) {
        indiceIcons = 6
    }
    
    //funcao que gera o resultado final
    @IBAction func finalResult(_ sender: Any) {
        // Do any additional setup after loading the view.
    }
    
    @IBAction func finalResultsGeneration(_ sender: Any) {
        brandTitle.returnKeyType = .done
        brandTitle.autocapitalizationType = .words
        brandTitle.delegate = self
        brandTitle.resignFirstResponder()
        
        result1.image = UIImage(named: icons[indiceIcons])
        resultText.text = brandTitle.text
        resultText.font = UIFont(name:fonts[indiceFontes], size: 30)
        resultPalet.image = UIImage(named: paletas[indicePaletas])
        
        hexa1.text = hexColors1[indicePaletas]
        hexa2.text = hexColors2[indicePaletas]
        hexa3.text = hexColors3[indicePaletas]
        imgDecorativa.layer.cornerRadius = 10
        
    }
}

//Configurando botão de texto


extension BrandViewController: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
    //essa funcao faz com que a tecla return do teclado faca o app aceitar a entrada e o teclado abaixe
    textField.resignFirstResponder()
    return true
    }
}
