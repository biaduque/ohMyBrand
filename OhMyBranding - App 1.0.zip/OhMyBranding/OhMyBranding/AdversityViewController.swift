//
//  AdversityViewController.swift
//  OhMyBranding
//
//  Created by Beatriz Duque on 03/06/21.
//

import UIKit

class AdversityViewController: UIViewController {

    
    @IBOutlet weak var field: UITextField!
    @IBOutlet weak var post1: UIButton?
    @IBOutlet weak var post2: UIButton?
    @IBOutlet weak var post3: UIButton?
    
    @IBOutlet weak var saveButton: UIButton?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //configurando o espaço de insercao de texto
        field.returnKeyType = .done
        field.autocapitalizationType = .words
        field.delegate = self
        
        post1?.layer.cornerRadius = 10
        post2?.layer.cornerRadius = 10
        post3?.layer.cornerRadius = 10
        
        saveButton?.layer.cornerRadius = 10

    }

    @IBAction func saveAction(_ sender: Any) {
        field.returnKeyType = .done
        field.autocapitalizationType = .words
        field.delegate = self
        field.resignFirstResponder()
    }
}

extension AdversityViewController: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //essa funcao faz com que a tecla return do teclado faca o app aceitar a entrada e o teclado abaixe
        textField.resignFirstResponder()
        return true
    }
}
