//
//  IntroductionViewController.swift
//  OhMyBranding
//
//  Created by Beatriz Duque on 15/06/21.
//

import UIKit

class IntroductionViewController: UIViewController {

    @IBOutlet weak var continueButton: UIButton?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        continueButton?.layer.cornerRadius = 10
        // Do any additional setup after loading the view.
    }


}
