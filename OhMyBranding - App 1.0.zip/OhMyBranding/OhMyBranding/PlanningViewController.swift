//
//  PlanningViewController.swift
//  OhMyBranding
//
//  Created by Beatriz Duque on 01/06/21.
//

import Foundation
import UIKit



class TableViewController2: UIViewController {
    var contaTaks: Int = 0
    var imagensProgressos = ["fase1","fase2","fase3","fase4","fase5"]
    //imagem que apresenta o progresso
    @IBOutlet weak var imgProgress: UIImageView?
    
    //declarando o botao de cada task
    @IBOutlet weak var task1: UIButton!
    @IBOutlet weak var task2: UIButton!
    @IBOutlet weak var task3: UIButton!
    @IBOutlet weak var task4: UIButton!
    @IBOutlet weak var task5: UIButton!
    @IBOutlet weak var task6: UIButton!
    
    //variavel de tasks concluidas
    var tasks = ["X","X","X","X","X","X"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //funcoes que checam cada task
    @IBAction func checkTask1(_ sender: Any) {
        let aux = verificaTask(button: task1, alternativa: "OK", respostaX: tasks[0])
        tasks[0] = aux
        imgProgress?.image = UIImage(named: "fase2")
    }
    @IBAction func checkTask2(_ sender: Any) {
        let aux = verificaTask(button: task2, alternativa: "OK", respostaX: tasks[1])
        tasks[1] = aux
        imgProgress?.image = UIImage(named: "fase3")
    }
    @IBAction func checkTask3(_ sender: Any) {
        let aux = verificaTask(button: task3, alternativa: "OK", respostaX: tasks[2])
        tasks[2] = aux
        imgProgress?.image = UIImage(named: "fase3")
    }
    @IBAction func checkTask4(_ sender: Any) {
        let aux = verificaTask(button: task4, alternativa: "OK", respostaX: tasks[3])
        tasks[3] = aux
        imgProgress?.image = UIImage(named: "fase3")
    }
    @IBAction func checkTask5(_ sender: Any) {
        let aux = verificaTask(button: task5, alternativa: "OK", respostaX: tasks[4])
        tasks[4] = aux
        imgProgress?.image = UIImage(named: "fase4")
    }
    
    @IBAction func checkTask6(_ sender: Any) {
        let aux = verificaTask(button: task6, alternativa: "OK", respostaX: tasks[5])
        tasks[5] = aux
        imgProgress?.image = UIImage(named: "fase5")
    }
    
    
    func verificaTask(button: UIButton, alternativa: String, respostaX: String)-> String{
        if (respostaX != "X"){
            button.setImage(UIImage(systemName: "checkmark.circle.fill"), for: .normal)
            return "X"
        }
        else{
            button.setImage(UIImage(systemName: "checkmark.circle.fill"), for: .normal)
            return alternativa
        }
    }
}
