//
//  PostsViewController.swift
//  OhMyBranding
//
//  Created by Beatriz Duque on 15/06/21.
//

import UIKit

class PostsViewController: UIViewController {

    @IBAction func postExit1(_ sender: Any) {
    }
    @IBAction func postExit2(_ sender: Any) {
    }
    @IBAction func postExit3(_ sender: Any) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func exit3(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    @IBAction func exit2(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    @IBAction func exit1(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
}
