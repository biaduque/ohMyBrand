//
//  ViewController.swift
//  OhMyBranding
//
//  Created by Beatriz Duque on 01/06/21.
//

import UIKit
var indiceFontes = 0
var indicePaletas = 0
var indiceIcons = 0
var raio = 5
var clickTop = false
var clickPalet = false
var clickIcon = false

//let myColor = UIColor( red: 1, green: 0.9647, blue:0.94509, alpha: 1.0 )
let myColor = UIColor( red: 0.0666, green: 0.2352, blue:0.23137, alpha: 1.0 )

let colorDefault = UIColor( red: 0.0666, green: 0.2352, blue:0.23137, alpha: 1.0 )

class BrandViewController: UIViewController {
    
    //ImageView decorativa
    @IBOutlet weak var imgDecorativa: UIImageView?
    
    
    //variavel que guarda o tipo de texto
    let fonts = ["KohinoorBangla-Regular","SF-Compact","TimesNewRomanPSMT"]
    
    //variavel que guarda o tipo de paleta
    let paletas = ["final0","final1","final2","final3","final4","final5"]
    
    //variavel que guarda os icones
    let icons = ["logo1","logo2","logo3","logo4","logo5","logo6","logo7","logo8"]
    
    
    //vetores com o Hex
    let hexColors1 = ["#8D8989","#8B3030","#CCB4DD","#AAD8D3","#F6DCBF","#282746"]
    let hexColors2 = ["#0F3319","#D69393","#FFC4C4","#09ADB5","#F6A540","#047580"]
    let hexColors3 = ["#FFFFFF","#C4C4C4","#C4F4FF","#393E46","#E0711A","#FDD149"]
    
    //Botoes de tipografia
    
    @IBOutlet weak var tipo1: UIButton!
    @IBOutlet weak var tipo2: UIButton!
    @IBOutlet weak var tipo3: UIButton!
    
    
    //Botoes de paletas
    @IBOutlet weak var palet1: UIButton!
    @IBOutlet weak var palet2: UIButton!
    @IBOutlet weak var palet3: UIButton!
    @IBOutlet weak var palet4: UIButton!
    @IBOutlet weak var palet5: UIButton!
    @IBOutlet weak var palet6: UIButton!
    
    //botoes de logos
    @IBOutlet weak var logo1: UIButton!
    @IBOutlet weak var logo2: UIButton!
    @IBOutlet weak var logo3: UIButton!
    @IBOutlet weak var logo4: UIButton!
    @IBOutlet weak var logo5: UIButton!
    @IBOutlet weak var logo6: UIButton!
    @IBOutlet weak var logo7: UIButton!
    @IBOutlet weak var logo8: UIButton!
    
    // Variaveis que armazenarao os resultados
    @IBOutlet weak var result1: UIImageView?
    @IBOutlet weak var resultText: UILabel?
    @IBOutlet weak var resultPalet: UIImageView?
    @IBOutlet weak var hexa1: UILabel?
    @IBOutlet weak var hexa2: UILabel?
    @IBOutlet weak var hexa3: UILabel?
    
    //variaveis de armazenamentolocal
    var myResult: UILabel = UILabel()
    @IBOutlet weak var submitButton: UIButton?
    @IBOutlet weak var brandResult: UIButton?
    
    
    //lets try Button
    @IBOutlet weak var letsTryButton2: UIButton?
    
    
    //textField que guarda a variavel com o nome
    @IBOutlet weak var brandTitle: UITextField!
    
    //botao que gera resultado
    @IBOutlet weak var showResults: UIImageView!
    
    //botao de exit
    @IBOutlet weak var exitButton: UIButton!
    
    //botao de back
    @IBOutlet weak var backButton: UIButton!
    
    //background da imagem
    @IBOutlet weak var imgBackgroundDigital: UIImageView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        submitButton?.layer.cornerRadius = 10
        letsTryButton2?.layer.cornerRadius = 10
        brandResult?.layer.cornerRadius = 10
        imgDecorativa?.layer.cornerRadius = 10
        imgBackgroundDigital?.layer.cornerRadius = 10
    
        //resultados gerados
        
        result1?.image = UIImage(named: icons[indiceIcons])
        resultText?.font = UIFont(name:fonts[indiceFontes], size: 30)
        resultPalet?.image = UIImage(named: paletas[indicePaletas])
        resultText?.text = "My Brand"
        hexa1?.text = hexColors1[indicePaletas]
        hexa2?.text = hexColors2[indicePaletas]
        hexa3?.text = hexColors3[indicePaletas]
    }
    
    
    //funcoes que setam as fontes selecionadas
    @IBAction func choose1(_ sender: Any) {
        configureButton(button: tipo1, indice: 0)
        indiceFontes = 0
    }
    @IBAction func choose2(_ sender: Any) {
        configureButton(button: tipo2, indice: 1)
        indiceFontes = 1
    }
    @IBAction func choose3(_ sender: Any) {
        configureButton(button: tipo3, indice: 2)
        indiceFontes = 2
    }
    
    //funcoes que setam a paleta de cor selecionada
    
    @IBAction func choosePalet1(_ sender: Any) {
        configureButtonPallet(button: palet1, indice: 0)
    }
    @IBAction func choosePalet2(_ sender: Any) {
        configureButtonPallet(button: palet2, indice: 1)

    }
    @IBAction func choosePalet3(_ sender: Any) {
        configureButtonPallet(button: palet3, indice: 2)

    }
    @IBAction func choosePalet4(_ sender: Any) {
        configureButtonPallet(button: palet4, indice: 3)

    }
    @IBAction func choosePalet5(_ sender: Any) {
        configureButtonPallet(button: palet5, indice: 4)

    }
    @IBAction func choosePalet6(_ sender: Any) {
        configureButtonPallet(button: palet6, indice: 5)
    }

    //funcoes que setam o icone selecionado
    
    @IBAction func chooseIcon1(_ sender: Any) {
        configureButtonIcon(button: logo1, indice: 0)
    }
    @IBAction func chooseIcon2(_ sender: Any) {
        configureButtonIcon(button: logo2, indice: 1)

    }
    @IBAction func chooseIcon3(_ sender: Any) {
        configureButtonIcon(button: logo3, indice: 2)

    }
    @IBAction func chooseIcon4(_ sender: Any) {
        configureButtonIcon(button: logo4, indice: 3)

    }
    @IBAction func chooseIcon5(_ sender: Any) {
        configureButtonIcon(button: logo5, indice: 4)

    }
    @IBAction func chooseIcon6(_ sender: Any) {
        configureButtonIcon(button: logo6, indice: 5)

    }
    @IBAction func chooseIcon7(_ sender: Any) {
        configureButtonIcon(button: logo7, indice: 6)

    }
    @IBAction func chooseIcon8(_ sender: Any) {
        configureButtonIcon(button: logo8, indice: 7)
    }
    
    //funcao que gera o resultado final
    @IBAction func finalResult(_ sender: Any) {
        // Do any additional setup after loading the view.
    }
    
    @IBAction func finalResultsGeneration(_ sender: Any) {
        brandTitle.returnKeyType = .done
        brandTitle.autocapitalizationType = .words
        brandTitle.delegate = self
        brandTitle.resignFirstResponder()
        //trocando o texto da marca
        resultText?.text = brandTitle.text
    }
    
    @IBAction func exitFunction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func backFunction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    func configureButton(button: UIButton, indice: Int){
        button.layer.cornerRadius = 2
        button.layer.borderWidth = 3
        if (clickTop == true){
            button.layer.borderWidth = 0
            clickTop = false
        }
        else{
            button.layer.borderColor = myColor.cgColor
            indiceFontes = indice
            clickTop = true
        }
    }
    
    func configureButtonPallet(button: UIButton, indice: Int){
        button.layer.cornerRadius = 2
        button.layer.borderWidth = 3
        if (clickPalet == true){
            button.layer.borderWidth = 0
            clickPalet = false
        }
        else{
            button.layer.borderColor = myColor.cgColor
            indicePaletas = indice
            clickPalet = true
        }
    }
    
    func configureButtonIcon(button: UIButton, indice: Int){
        button.layer.cornerRadius = 2
        button.layer.borderWidth = 3
        if (clickIcon == true){
            button.layer.borderWidth = 0
            clickIcon = false
        }
        else{
            button.layer.borderColor = myColor.cgColor
            indiceIcons = indice
            button.layer.borderWidth = 3
            clickIcon = true
        }
    }
}


//Configurando botão de texto

extension BrandViewController: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
    //essa funcao faz com que a tecla return do teclado faca o app aceitar a entrada e o teclado abaixe
    textField.resignFirstResponder()
    return true
    }
}
