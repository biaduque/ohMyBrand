//
//  infoViewController.swift
//  OhMyBranding
//
//  Created by Beatriz Duque on 16/06/21.
//

import UIKit

class infoViewController: UIViewController {

    @IBOutlet weak var advertisingInfo: UIButton!

    @IBOutlet weak var homeInfo: UIButton!
    
    @IBOutlet weak var brandInfo: UIButton!
    
    @IBOutlet weak var strategyInfo: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func checkInfoAdv(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }

    @IBAction func checkInfoHome(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func checkInfoBrand(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func checkStrategyInfo(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
}
