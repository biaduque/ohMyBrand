//
//  StrategyViewController.swift
//  OhMyBranding
//
//  Created by Beatriz Duque on 02/06/21.
//

import Foundation
import UIKit

class StrategyViewController: UIViewController{
    
    //vetor que armazena respostas
    var resposta1: String = "X"
    var resposta2: String = "X"
    var resposta3: String = "X"
    var respostaFinal: String = ""
    
    //variavel que guarda a rede indicada para estrategia do usuario
    @IBOutlet weak var redeEstrategia: UILabel!
    
    
    //botao que faz gerar resultado
    @IBOutlet weak var buttonResult: UIButton!
    
    //declaracoes de botoes
    @IBOutlet weak var button1A: UIButton!
    @IBOutlet weak var button1B: UIButton!
    @IBOutlet weak var button1C: UIButton!
    
    @IBOutlet weak var button2A: UIButton!
    @IBOutlet weak var button2B: UIButton!
    @IBOutlet weak var button2C: UIButton!
    
    @IBOutlet weak var button3A: UIButton!
    @IBOutlet weak var button3B: UIButton!
    @IBOutlet weak var button3C: UIButton!
    
    //declarando os labels que recebem o hexadecimal
    
    
    
    override func viewDidLoad() {
        view.backgroundColor = .white
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    //computando respostas da questao 1
    @IBAction func question1A(_ sender: Any) {
        let aux = verifica(button: button1A, alternativa: "A", respostaX: resposta1)
        resposta1 = aux
    }
    @IBAction func question1B(_ sender: Any) {
        let aux = verifica(button: button1B, alternativa: "B", respostaX: resposta1)
        resposta1 = aux
    }
    @IBAction func question1C(_ sender: Any) {
        let aux = verifica(button: button1C, alternativa: "C", respostaX: resposta1)
        resposta1 = aux
    }
    
    //computando respostas da questao 2
    
    @IBAction func question2A(_ sender: Any) {
        let aux = verifica(button: button2A, alternativa: "A", respostaX: resposta2)
        resposta2 = aux
        
    }
    @IBAction func question2B(_ sender: Any) {
        let aux = verifica(button: button2B, alternativa: "B", respostaX: resposta2)
        resposta2 = aux
    }
    @IBAction func question2C(_ sender: Any) {
        let aux = verifica(button: button2C, alternativa: "C", respostaX: resposta2)
        resposta2 = aux
    }
    
    //computando respostas da questao 3
    
    @IBAction func question3A(_ sender: Any) {
        let aux = verifica(button: button3A, alternativa: "A", respostaX: resposta3)
        resposta3 = aux
    }
    @IBAction func question3B(_ sender: Any) {
        let aux = verifica(button: button3B, alternativa: "B", respostaX: resposta3)
        resposta3 = aux
    }
    @IBAction func question3C(_ sender: Any) {
        let aux = verifica(button: button3C, alternativa: "C", respostaX: resposta3)
        resposta3 = aux
    }
    
    
    func verifica(button: UIButton, alternativa: String, respostaX: String)-> String{
        if (respostaX != "X"){
            button.setImage(UIImage(systemName: "circle"), for: .normal)
            return "X"
        }
        else{
            button.setImage(UIImage(systemName: "circle.fill"), for: .normal)
            return alternativa
        }
    }
    
    func geraResultado(){
        respostaFinal.append(resposta1)
        respostaFinal.append(resposta2)
        respostaFinal.append(resposta3)
        
        
        if (respostaFinal == "AAA" || respostaFinal == "AAB" || respostaFinal == "CAA" || respostaFinal == "CBB" || respostaFinal == "CCA" || respostaFinal == "CCB" || respostaFinal == "CCC" ){
            redeEstrategia.text = "Facebook"
        }
        else if (respostaFinal == "BCA" || respostaFinal == "BCC" ){
            redeEstrategia.text = "Twitter"
        }
        else if (respostaFinal == "ABA" || respostaFinal == "ACC"){
            redeEstrategia.text = "TikTok"
        }
        else if (respostaFinal == "ABB" || respostaFinal == "ABC" || respostaFinal == "BBA" || respostaFinal == "BBC" || respostaFinal == "CBC"  ){
            redeEstrategia.text  = "YouTube"
        }
        else{
            redeEstrategia.text = "Instagram"
        }
    }
    @IBAction func buttonResultActive(_ sender: Any) {
        geraResultado()
    }
    
    
}
